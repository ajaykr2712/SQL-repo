
178 Rank Scores

Write a SQL query to rank scores. If there is a tie between two scores, both should have the same ranking. Note that after a tie, the next ranking number should be the next consecutive integer value. In other words, there should be no "holes" between ranks.

+----+-------+
| Id | Score |
+----+-------+
| 1  | 3.50  |
| 2  | 3.65  |
| 3  | 4.00  |
| 4  | 3.85  |
| 5  | 4.00  |
| 6  | 3.65  |
+----+-------+
For example, given the above Scores table, your query should generate the following report (order by highest score):

+-------+------+
| Score | Rank |
+-------+------+
| 4.00  | 1    |
| 4.00  | 1    |
| 3.85  | 2    |
| 3.65  | 3    |
| 3.65  | 3    |
| 3.50  | 4    |
+-------+------+


#MYSQL Query Accepted

Method 1:

SELECT Score, DENSE_RANK() OVER (PARTITION BY Score ORDER BY Score DESC) AS Rank
FROM Scores


Method 2:
SELECT S2.Score, (SELECT COUNT(DISTINCT S1.Score) FROM Scores S1 WHERE S1.Score >= S2.Score ) AS Rank
FROM Scores S2
ORDER BY Rank
